# AgroTwin - Hồ sơ địa bàn và demo gửi Bích

> Bản 1.3, 12/11/2026. Hồ sơ nghiên cứu và phương án demo; chưa là khảo sát thực địa hoặc khuyến cáo sản xuất. Thay thế cách diễn giải ranh 17 ha và mẫu đất địa phương trong các tài liệu/PDF trước lượt kiểm này. Không thay quyết định chọn challenge của team.

## 1. Chốt gì để bắt đầu làm?

**Giữ Mỹ Thành, Đồng Tháp, làm địa bàn nghiên cứu từ xa cho prototype Field Shift. Không cần lấy đất từ Mỹ Thành để làm demo.** Dùng một khối canh tác nhìn thấy trên ảnh làm vị trí minh họa, dữ liệu đất mô hình để đặt câu hỏi và cảm biến thật đo giá thể tại bàn HCM. Giữ nguồn gốc ba luồng này riêng trong giao diện và lời kể.

Đây là lựa chọn thực dụng để khóa nghiên cứu địa điểm; triển khai submission chỉ sau T0 được BTC cho phép, chưa chứng minh tối ưu toàn vùng hoặc đủ căn cứ trồng cả hai cây. Cả Mỹ Thành lẫn Cần Giờ chưa có ruộng được team xác minh. Khoảng cách đến HCM ít quyết định khi team không thể khảo sát.

| Thuật ngữ | Thực chất là gì? | Được dùng vào việc gì? |
| --- | --- | --- |
| Ranh canh tác trên ảnh | Cạnh của một khối nhìn thấy tại ngày ảnh | Định vị, đọc ảnh, chọn phạm vi minh họa |
| SoilGrids | Dự đoán tính chất đất trên grid, có bất định | Sàng lọc giả thuyết, ghi thiếu thông tin |
| Mẫu đất demo | Đất/giá thể thật được mua hoặc lấy có ghi nguồn tại HCM | Kiểm cảm biến, truyền dữ liệu và mô phỏng |

Ba thứ này không tự thay thế nhau. Vẽ một polygon không biến khu vực thành đất đồng nhất; cảm biến độ ẩm cũng không xác định được loại đất hoặc lịch luân canh.

**Câu chuyện đề xuất:** Một người trồng trọt cần cân nhắc phương án mùa vụ trước điều kiện khí hậu biến động. AgroTwin kết hợp dữ liệu NASA, thông tin đất có nguồn, yêu cầu cây và ưu tiên người dùng để so sánh lựa chọn, giải thích rủi ro và chỉ ra điều chưa biết. Node tại bàn được đề xuất để kiểm khả năng nhận dữ liệu tại chỗ, chưa có kết quả chạy được kiểm; chưa chứng minh năng suất hay tiết kiệm nước ngoài đồng.

## 2. Phạm vi xã và vị trí minh họa

![Ranh xã Mỹ Thành có nguồn](maps/my-thanh-commune-aoi.png)

**AOI-MT-ADMIN-v1:** ranh xã từ bản đồ NXB Tài nguyên - Môi trường và Bản đồ Việt Nam [S1], diện tích thuộc tính nguồn 52,3 km². Không phải toàn bộ diện tích trồng cây hằng năm. Giữ geometry nguồn, không dựng lại bằng bbox hoặc vài góc tự chọn. Nguồn ảnh nền là mosaic Esri và các nhà cung cấp ghi ngay trên hình.

Chấm xanh là query POWER/SoilGrids cũ, không phải điểm lấy mẫu. Khối minh họa mới MT-BLOCK-01 có tâm khác, xem trang tiếp theo. Không dùng dữ liệu tại một điểm làm trung bình cả xã.

## 3. Khoanh theo cạnh nhìn thấy, bỏ hình thoi cũ

![Khối canh tác số hóa theo ảnh](maps/my-thanh-study-block-detail.png)

**MT-BLOCK-01:** khoảng 2,00 ha; tâm 10.4790981 N, 106.0216210 E. Ranh vàng mảnh bám mép khối canh tác cạnh các dải cây và bờ nhìn được trên ảnh. Có thể chứa nhiều ô nhỏ; chưa là ranh địa chính hoặc một hộ. Ngày metadata ảnh nguồn 07/08/2025, chưa xác minh hiện trạng ruộng năm 2026. Các ảnh Sentinel-2 năm 2026 đã có ở hồ sơ vùng nhưng chưa được phân tích chuỗi thời gian riêng cho block mới.

| Đỉnh | Vĩ độ N | Kinh độ E | Đỉnh | Vĩ độ N | Kinh độ E |
| --- | --- | --- | --- | --- | --- |
| A | 10.479886 | 106.021194 | E | 10.478764 | 106.020756 |
| B | 10.479430 | 106.022478 | F | 10.478944 | 106.020828 |
| C | 10.478416 | 106.022100 | G | 10.479280 | 106.020960 |
| D | 10.478314 | 106.022064 | H | 10.479604 | 106.021080 |

Đi theo A-B-C-D-E-F-G-H-A. CSV giữ cả tọa độ pixel nguồn để kiểm cách số hóa. Chữ số tọa độ không phải sai số đo. Không có kiểm chứng ranh độc lập; diện tích là xấp xỉ, không phải diện tích quyền sử dụng đất.

## 4. SoilGrids có nói đất này đồng nhất không?

**Không.** SoilGrids là mô hình tính chất đất, native support khoảng 250 m [S2]. Block khoảng 2 ha nhỏ hơn diện tích một ô native danh nghĩa 250 x 250 m (6,25 ha). Raster xuất lại có pixel nhỏ hoặc nhiều chữ số cũng không tạo thêm thông tin đất thực. Hai điểm cùng một ô không chứng minh hai mẫu đất giống nhau; một polygon màu đơn trên bản đồ cũng vậy.

Đã lấy riêng giá trị ô mô hình chứa tâm MT-BLOCK-01 từ 15 coverage cached, thay vì chép mẫu điểm cũ sang block. Output EPSG:4326; thuật toán resample của dịch vụ chưa được xác minh. Đây là giá trị ô tại tâm, không phải trung bình block hoặc mẫu phân tích phòng thí nghiệm.

| Tính chất ở tâm block mới | Mean | Q05-Q95 |
| --- | --- | --- |
| pH H2O 0-5 cm | 6,3 | 4,5-8,3 |
| pH H2O 5-15 cm | 6,3 | 4,5-8,3 |
| pH H2O 15-30 cm | 6,3 | 4,5-8,3 |
| Cát 0-5 cm | 21,1% | 1,2-72,5% |
| Sét 0-5 cm | 35,3% | 0,4-93,2% |

Khoảng dự đoán rộng, không đủ chốt đất phù hợp cho bắp non hay đậu xanh. Không có EC, nguồn tưới, thoát nước, đế cày hoặc mẫu đất đại diện. Không chuyển các số này thành công thức pha chậu “đất Mỹ Thành”.

**Nhãn hiện hành:** ranh = số hóa theo ảnh; cây cụ thể = chưa biết; lịch luân canh = chưa biết; tính chất đất = mô hình; đất đồng nhất = chưa kiểm. Muốn khẳng định cùng loại đất cần bản đồ đất đủ chi tiết có phương pháp/niên đại hoặc lấy mẫu kiểm; không đáp ứng bằng khoanh tay. Với scope không thực địa, giữ giới hạn này và làm quyết định theo kịch bản.

## 5. Demo tại HCM: đất nào, đo gì, backup ra sao?

**Không yêu cầu lấy đất từ địa phương.** Chọn một lô đất/giá thể có nguồn và mô tả rõ tại HCM. Có thể chia cùng lô thành hai chậu/cốc để so phản ứng khô hơn - ướt hơn; chưa cần trồng cây để kiểm ingestion. Không dùng chậu làm thí nghiệm chứng minh lợi ích luân canh.

<!-- FLOW -->

1. An kiểm datasheet board/probe: nguồn cấp, mức tín hiệu, ADC/bus và SDK. Chip/board HTTPSLAB đã được đồng ý cho mượn theo team; thông số và module thực tế còn chờ.
2. Ghi nguồn giá thể, ngày chuẩn bị, lượng đất, chậu, cách cắm và ID probe. Đánh dấu độ sâu để đo lặp nhất quán; ghi thời điểm tác động nước. Không mặc định giá thể có cùng pH/EC/cấu trúc với Mỹ Thành.
3. Hiệu chuẩn theo nhà sản xuất. Nếu chỉ có hai mốc khô/ướt, hiển thị chỉ số độ ẩm tương đối; chưa ghi % VWC. Muốn VWC cần tham chiếu lượng nước theo thể tích và quy trình hiệu chuẩn phù hợp [S3].
4. Đo lặp trạng thái ổn định, lưu raw signal, timestamp, đơn vị và trạng thái hợp lệ. Quang Luật kiểm độ phân tán, missing/stale và khả năng phát hiện ngắt probe. Chưa có thông số nên chưa đặt ngưỡng chính xác hoặc tần số đo thay cho datasheet.
5. Dashboard hiển thị `HCM_tabletop` riêng với `MyThanh_scenario`. Cho phép dùng tín hiệu lab để tương tác mô phỏng, đồng thời giữ mưa/nhiệt NASA và giả định mùa vụ có nhãn riêng. Không biến một lần tưới chậu thành khuyến cáo đổi cây ngoài đồng.

**Backup:** board chưa tích hợp được thì replay log có nguồn, ghi rõ recorded; chưa có log thì dữ liệu synthetic gắn nhãn. Thiếu hiệu chuẩn thì dùng relative index. Thiếu EC/pH thì giữ unknown, không tự suy từ độ ẩm. Một nhánh gặp lỗi không làm mất phần so sánh luân canh.

## 6. Hai phương án luân canh và El Niño

Theo brief Field Shift người dùng cung cấp, trọng tâm là hỗ trợ khám phá luân canh bằng NASA EO, đất, yêu cầu cây và ưu tiên nông dân; hardware là phần bổ sung. Resources chính thức chưa được kiểm đầy đủ. Ba phương án bên dưới là tiêu chí MVP NeuraX chọn, không tuyên bố mọi mục đều bắt buộc bởi NASA.

| ID | Phương án tham khảo | Bằng chứng và trạng thái |
| --- | --- | --- |
| R0 | Lúa liên tục | Đối chứng nghiên cứu lịch sử, chưa xác nhận hiện trạng block |
| R1 | Lúa - bắp non - lúa | Nghiên cứu Cai Lậy/Long Khánh [S4, S5]; chưa xác minh tại Mỹ Thành |
| R2 | Lúa - đậu xanh - lúa | Nghiên cứu vùng [S4, S5]; cần rà điều kiện và lịch mùa cụ thể |

Không đổi bắp non thành bắp hạt CP888 hoặc đậu xanh thành đậu phộng GV10 từ hồ sơ Đức Lập. Chưa có giống/ngày gieo/thu/nguồn nước và hiệu quả đã kiểm tại block. Cần tách bằng chứng vùng khỏi thửa cụ thể; số trung bình công bố không phải raw training labels.

NASA POWER đã tải 4.018 ngày 2015-2025 tại điểm vùng gần block [S6], không phải số đo microclimate trong ruộng. Giữ cờ mưa 488,17 mm ngày 14/06/2020 để kiểm tiếp; không tự sửa. Sentinel-2 là Copernicus qua Planetary Computer, SoilGrids là ISRIC, ENSO là NOAA; không gộp tất cả thành dữ liệu NASA.

**El Niño có thể là input bối cảnh:** outlook có ngày nguồn -> khám phá bất thường mưa/nhiệt địa phương -> chạy kịch bản nóng/khô -> so độ nhạy lựa chọn. Trang NOAA đọc ngày 12/11 vẫn hiển thị bản 08/10/2026 [S7]. Chưa có quan hệ địa phương được kiểm nên không gắn hệ số giảm mưa hoặc xác suất hạn cho block. Slider là scenario, không phải forecast. Không dùng outlook hiện tại làm feature lịch sử đã biết trước.

**Liên hệ NASA -> so phương án còn thiếu:** hiện chưa có response rule đủ căn cứ để chuyển mưa/nhiệt thành utility hoặc thứ hạng cây. Chart khí hậu + ba thẻ tĩnh chưa chứng minh giải phần decision support. Cần Bích/Hưng/Việt review rule và Luật kiểm trước khi đưa vào phép so. Chưa đủ thì score=null/needs_review; R0 is_current=null, không tự nhận là hiện trạng block. AI ở đây có thể là baseline giải thích được, không bắt buộc ML hoặc forecast.

**Gate quyết định:** thiếu tiêu chí đất/nước quan trọng -> trả “chưa đủ thông tin”; có ràng buộc loại trừ có nguồn -> không xếp phương án đó là phù hợp; chỉ so sánh kịch bản khi giả định được hiển thị và người dùng xác nhận. Chưa chấm điểm tiết kiệm nước, năng suất hay lợi nhuận từ cảm tính.

**Bảng chi tiết để review:** [đất-nước-cây-mùa cho R0/R1/R2](rotation-evidence-for-bich.md) và [CSV 12 hàng để Bích ghi review](rotation-evidence-review.csv). Vai trò sáu thành viên nằm ở mục 11 của PDF.

# Bảng đất - nước - cây - mùa để Bích review

> 12/11/2026, bản 1.1. Mỹ Thành được giữ làm địa bàn nghiên cứu. Ba phương án dưới đây là reference scenarios, chưa là lịch canh tác xác minh của MT-BLOCK-01. Không mở rộng địa bàn hoặc giao khảo sát thực địa. Bích review bằng nguồn và ghi giới hạn; không được coi là xác nhận chuyên môn nông học ngoài phạm vi năng lực.

## 7. Bằng chứng chung và cách đọc bảng

**Mục đích:** xác định điều gì có thể đưa vào prototype so sánh và điều gì phải giữ unknown. Không dùng bảng này làm lịch gieo, công thức bón/tưới hoặc kết luận phương án tối ưu cho một ruộng.

| Nhãn | Ý nghĩa | Cách dùng |
| --- | --- | --- |
| HISTORICAL | Có trong nghiên cứu lịch sử tại Cai Lậy/Long Khánh | Dùng làm tham chiếu, giữ địa danh/năm; chưa chuyển sang Mỹ Thành |
| MODEL | Được mô hình dự đoán tại ô chứa tâm block | Hiển thị nguồn và bất định; không thay mẫu đất đo |
| UNKNOWN | Chưa có bằng chứng đủ cho block hoặc rule cụ thể | Hỏi người dùng/ghi thiếu; không chấm là phù hợp |
| SCENARIO | Giả định do team/người dùng chọn | Gắn nhãn, không gọi là hiện trạng hoặc dự báo |

**Nguồn đã kiểm để bắt đầu review:**

- **[S4] CTU 2009, 11:194-199:** methods PDF trang 2 liệt kê ba chuỗi tại Long Khánh; bảng 1 trang 3 mô tả phẫu diện và vật lý đất; bảng 4 trang 5 có kết quả độ bền đoàn lạp. Khác biệt giữa nghiệm thức tại Long Khánh không có ý nghĩa thống kê ở outcome này; không mượn kết quả Vĩnh Mỹ để khẳng định lợi ích chắc chắn. [PDF](https://ctujsvn.ctu.edu.vn/index.php/ctujsvn/article/download/605/3214/3214).
- **[S5] CTU 2009, 11:262-269:** methods PDF trang 2 mô tả đất phù sa Mollic Endoaquept, trong vùng bao đê, thí nghiệm tiếp nối từ 2001; bảng 1 trang 3 cho chuỗi theo vụ. Đánh giá mẫu năm 2005, bảng đất đầu kỳ là năm 2001. Không chứng minh cùng thửa với S4. [PDF](https://ctujsvn.ctu.edu.vn/index.php/ctujsvn/article/download/597/3222/3222).
- **[S2] SoilGrids tại tâm block:** pH H2O mean 6,3 ở ba tầng tới 30 cm, Q05-Q95 4,5-8,3; cát/sét tầng 0-5 cm có khoảng rộng. Đây là MODEL, không xác nhận nhóm đất, EC, tầng đế cày hoặc đồng nhất toàn block. [JSON](study-block-soil-model.json), [CSV](study-block-soil-model.csv).
- **[S6] NASA POWER:** chuỗi điểm vùng 2015-2025 đã có QA/WARN; chưa tính cân bằng nước hay cửa sổ mùa tối ưu cho ba phương án. Mưa không thay lưu lượng tưới, thoát nước hoặc nguồn nước mặn/ngọt.

Giữ riêng đất nghiên cứu lịch sử, đất mô hình tại Mỹ Thành và giá thể demo HCM. Không ghép số đo thành một record hoặc lấy bảng tổng hợp làm raw training samples. Bảng này không thêm ngưỡng pH/EC, thời gian giống hoặc nhu cầu nước khi chưa có tài liệu đúng cây, phương pháp và phạm vi áp dụng.

## 8. R0 - lúa / lúa / lúa

**Vai trò:** đối chứng tham khảo, không mặc định là hiện trạng MT-BLOCK-01. Lịch HISTORICAL [S5, bảng 1]: lúa Đông Xuân -> lúa Hè Thu -> lúa Thu Đông. Chưa có ngày gieo/thu hoặc giống cụ thể để áp năm 2026.

| Yếu tố | Đã có và phạm vi bằng chứng | Chưa đủ tại Mỹ Thành / Bích cần review |
| --- | --- | --- |
| Đất | HISTORICAL: S4 có phẫu diện đất lúa Long Khánh và tầng nén dẽ; S5 mô tả đất phù sa của thí nghiệm Cai Lậy. MODEL: SoilGrids tại tâm block | UNKNOWN nhóm đất thực, đế cày, phèn/mặn, điều kiện rễ. Cần nguồn đất có tỷ lệ bản đồ/vị trí/năm; chưa được chuyển tên đất S5 sang block |
| Nước | S5 là vùng bao đê; đã có khí tượng NASA vùng. Đây chưa là bằng chứng đủ nước cho ba vụ ở block | UNKNOWN nguồn tưới, lịch cấp, độ mặn nước, thoát nước và rủi ro ngập. Không suy “không ngập lũ” thành không úng; chưa tính được tổng nước tưới |
| Cây | HISTORICAL: lúa là cây trong cả ba vụ của đối chứng S4/S5 | UNKNOWN giống, thời gian giống, yêu cầu pH/EC theo phương pháp, sâu bệnh và mục tiêu hộ. Không lấy soil mean làm chứng nhận cây phù hợp |
| Mùa | HISTORICAL: Đông Xuân - Hè Thu - Thu Đông theo bảng S5 | UNKNOWN ngày gieo/thu, khoảng nghỉ và lịch địa phương hiện thời; khung tên vụ chưa bảo đảm ba vụ nối được |

**Kết luận hiện hành:** đủ để đặt R0 cạnh hai lựa chọn trong reference comparison. **Chưa đủ để gọi là baseline nông hộ hiện tại, phù hợp hoặc bền vững ở Mỹ Thành.**

**Bích chốt bằng desk review:** (1) nguồn nào chứng minh lịch lúa hiện tại ở phạm vi xã/block; (2) điều kiện nước/đất nào được biết; (3) thiếu gì phải hỏi người dùng. Nếu không tìm được baseline block, giữ nhãn “đối chứng nghiên cứu”, không điền “đang trồng” vào giao diện.

**Gate đề xuất:** nếu người dùng chưa xác nhận baseline hoặc nước tưới, kết quả = UNKNOWN_FOR_FIELD. Không gán R0 điểm thua mặc định chỉ để làm nổi phương án thay thế.

## 9. R1 - lúa / bắp non / lúa

**Vai trò:** phương án tham khảo thay vụ Hè Thu bằng bắp non/bắp rau. Lịch HISTORICAL [S5, bảng 1]: lúa Đông Xuân -> bắp rau Hè Thu -> lúa Thu Đông. Giữ đúng sản phẩm bắp non; không thay bằng bắp hạt CP888 hoặc bắp nếp.

| Yếu tố | Đã có và phạm vi bằng chứng | Chưa đủ tại Mỹ Thành / Bích cần review |
| --- | --- | --- |
| Đất | HISTORICAL: S4 có chuỗi lúa-bắp non-lúa và mô tả vật lý đất vùng. Đây là lý do phải kiểm điều kiện chuyển lúa sang cây cạn | UNKNOWN khả năng làm đất, tầng nén dẽ, thông khí và thoát nước của block. Cần tài liệu đúng bắp non, nhóm đất và phương pháp; chưa có ngưỡng loại trừ số hóa được |
| Nước | Có chuỗi thí nghiệm tham khảo, chưa có lượng tưới so sánh đủ để chuyển sang block; NASA chỉ cho bối cảnh khí tượng | UNKNOWN cách thoát nước sau lúa, nguồn tưới lúc cần và mặn/phèn. Bích cần xác định điều kiện tưới/tiêu trong mùa bắp; không kết luận “ít nước hơn” theo tên cây |
| Cây | HISTORICAL: bắp non S4 / bắp rau S5 là cây được thử, không phải dữ liệu crop rule đầy đủ | UNKNOWN giống, số ngày đến thu sản phẩm non, yêu cầu đất/nước và đầu ra thị trường. Không dùng ngày thu bắp hạt; không đưa liều phân trong thí nghiệm thành khuyến cáo |
| Mùa | HISTORICAL: thay đúng vụ Hè Thu trong S5, sau đó trở lại lúa Thu Đông | UNKNOWN ngày giải phóng ruộng, chuẩn bị đất, thu bắp và chuẩn bị vụ lúa sau. Phải kiểm cửa sổ giống + thời gian chuyển vụ; chưa chứng minh không xung đột |

**Kết luận hiện hành:** có tiền lệ nghiên cứu cho cấu trúc R1, **chưa đủ khuyến nghị áp dụng tại block**. Không khẳng định chắc cải thiện cấu trúc đất, tiết kiệm nước hoặc tăng lợi nhuận; kết quả phụ thuộc outcome và điều kiện nghiên cứu.

**Bích ưu tiên:** nguồn về (1) bắp non đúng loại sản phẩm; (2) tưới/thoát nước khi chuyển từ ruộng lúa; (3) thời gian giống và khả năng trở lại vụ lúa sau. Ghi rõ địa bàn, mùa, phương pháp và bằng chứng có chuyển giao được không.

**Gate đề xuất:** chưa biết tưới/tiêu hoặc cửa sổ chuyển vụ -> UNKNOWN_FOR_FIELD. Chỉ đánh CONSTRAINT_VIOLATED khi có rule có nguồn và giá trị đầu vào đủ để đối chiếu; không tự đặt threshold.

## 10. R2 - lúa / đậu xanh / lúa

**Vai trò:** phương án tham khảo thay vụ Hè Thu bằng đậu xanh. Lịch HISTORICAL [S5, bảng 1]: lúa Đông Xuân -> đậu xanh Hè Thu -> lúa Thu Đông. Không thay bằng đậu phộng GV10, đậu nành hoặc suy rằng mọi cây họ đậu có cùng yêu cầu.

| Yếu tố | Đã có và phạm vi bằng chứng | Chưa đủ tại Mỹ Thành / Bích cần review |
| --- | --- | --- |
| Đất | HISTORICAL: chuỗi lúa-đậu xanh-lúa có trong S4/S5; S5 có thí nghiệm dinh dưỡng/chất hữu cơ của hệ luân canh | UNKNOWN ngưỡng pH/EC theo phương pháp, điều kiện rễ/thoát nước tại block. Không suy cố định N hoặc lợi ích đất tại Mỹ Thành chỉ vì có cây họ đậu |
| Nước | Có tiền lệ luân canh trong nghiên cứu, chưa có lượng tưới/tiêu của block; mưa NASA chưa phản ánh nước khả dụng vùng rễ | UNKNOWN rủi ro úng, thời điểm tưới và nguồn nước. Cần tài liệu yêu cầu nước đúng đậu xanh và giai đoạn; chưa tính được % tiết kiệm nước |
| Cây | HISTORICAL: đậu xanh là cây thử ở vụ giữa | UNKNOWN giống, thời gian thu, yêu cầu dinh dưỡng/bệnh và cách xử lý tàn dư. Không gán lượng N bổ sung hoặc lợi nhuận khi chưa có số đúng bối cảnh |
| Mùa | HISTORICAL: thay Hè Thu rồi trở về lúa Thu Đông theo S5 | UNKNOWN ngày gieo/thu, mưa lúc thu, thời gian làm đất và lịch vụ sau. Cần kiểm lịch giống cụ thể với cửa sổ địa phương; tên vụ chưa đủ |

**Kết luận hiện hành:** đủ làm reference scenario cùng R0/R1, **chưa đủ gọi R2 tốt nhất hoặc phù hợp cho ruộng**. Không mặc định xếp trên R1 vì là cây họ đậu.

**Bích ưu tiên:** tài liệu đúng đậu xanh về đất/úng/tưới, thời gian giống và thời điểm thu; bằng chứng nào hỗ trợ mục tiêu người dùng, bằng chứng nào chỉ là kỳ vọng. Kết quả cần so với R0 trên cùng outcome có nguồn, không gộp thành một điểm soil health tùy ý.

**Gate và cách review chung:** UNKNOWN_FOR_FIELD = thiếu điều kiện quan trọng; REFERENCE_ONLY = đủ giải thích lịch sử, chưa chuyển giao; CONSTRAINT_VIOLATED = có rule + input chứng minh xung đột. Đây là nhãn thiết kế đề xuất, chưa là model đã triển khai. CSV có 12 hàng đất/nước/cây/mùa để Bích ghi nguồn mới, reviewer_decision, reviewer_note và review_date. Để trống các ô review tới khi Bích thật sự review.

# Vai trò và bàn giao cho case Mỹ Thành

> 12/11/2026, bản 1.2 theo phân công mới của người dùng. Hưng và Việt cùng đóng góp chính cho team. Hiếu làm backend từ xa, có thời gian offline vì đi Đà Nẵng sáu ngày; chưa có khung online cụ thể. Khả năng tham gia remote theo lời Hiếu, chưa thay xác nhận của BTC. [Hồ sơ đội hình](team-profile-reference.md).

## 11. Vai trò sáu thành viên và công việc hiện tại

**Hưng và Việt là hai người cùng phụ trách phần đóng góp chính:** cùng làm features, pipeline data, kiến trúc và output cho demo. Hưng xây workflow chính, chốt scope Data -> AI; Việt tập trung technical AI và Data Analysis. Cả hai có thể làm dashboard UI/UX và hỗ trợ backend cho Hiếu.

| Owner / role | Job và đầu ra chính | Bàn giao / phối hợp |
| --- | --- | --- |
| Hưng - workflow chính / scope Data -> AI | Chốt luồng, phạm vi và logic quyết định; cùng Việt làm features, pipeline, kiến trúc và A1; cùng làm dashboard khi cần | Đồng sở hữu core với Việt. Bích review data/feature; Luật kiểm từng block. Không chỉ làm điều phối hoặc pitch |
| Việt - technical AI / Data Analysis | Phân tích dữ liệu, kỹ thuật AI; cùng Hưng làm features, pipeline, kiến trúc và output demo; cùng làm UI/UX và hỗ trợ backend | D1/A1/contract do Hưng-Việt cùng thống nhất. Không là người duy nhất gánh toàn bộ tích hợp |
| Bích - Data / review feature và nguồn | Làm phần Data theo chuyên ngành: rà nguồn, ý nghĩa biến, chất lượng/phạm vi, feature và bảng đất-nước-cây-mùa | Data/evidence + K1: nguồn, phương pháp, giả định, unknown. Bàn giao cho Hưng-Việt; phối hợp Luật, không chỉ góp ý domain |
| Hiếu - Backend, remote gián đoạn | Backend/API/adapter dữ liệu và kết quả trong các khoảng online; ghi cách chạy và bàn giao phần đang làm | Hưng-Việt hỗ trợ/tiếp quản khi Hiếu offline. Không mặc định Hiếu sở hữu toàn bộ UI hoặc có mặt tại venue |
| Tiểu An - demo ESP / sensor | Demo thiết bị, probe, giao tiếp, firmware và log; tích hợp dữ liệu đo lab có nhãn với output demo | H1: raw/timestamp/đơn vị/trạng thái. Luật kiểm; Hưng-Việt nối dashboard. Có nhánh recorded/synthetic đúng nhãn nếu chưa live được |
| Quang Luật - thống kê / đánh giá từng block / QA | Theo dõi từng block của workflow: input/output, thống kê phù hợp, tiêu chí đánh giá, lỗi và trạng thái; hỏi từng người để hiểu luồng và vướng mắc | Q1/E1 + bảng QA theo block: owner, trạng thái, bằng chứng, blocker, việc tiếp theo. Không chỉ QA cuối hoặc kiểm sensor |

**Khi Hiếu offline:** dùng contract và mẫu output đã thống nhất để Hưng-Việt tiếp tục core/UI; backend có hướng dẫn chạy, trạng thái và phần việc dang dở để bàn giao. Không để tích hợp hoặc demo phụ thuộc việc Hiếu trả lời tin nhắn ngay. Nếu cần replay, hiển thị đúng nhãn thay vì giả backend/live data đã sẵn.

**Việc Luật cần nắm:** nguồn data -> tiền xử lý -> features -> AI/so sánh -> backend -> dashboard -> ESP/sensor. “Block” ở đây là khối chức năng trong workflow; không chỉ polygon ruộng. Luật ghi ai đang làm gì, input/output có khớp không và phần nào cần Hưng-Việt quyết định.

**Trước T0:** chuẩn bị/nghiên cứu, xác nhận lịch online và quy định remote/artifact với BTC; chưa triển khai submission project trước giờ cho phép. **Sau T0:** thực hiện các job trên. [GO Team, 05/11/2026](https://github.com/nasa/spaceapps/discussions/1813). Hưng giữ scope; mọi người dùng cùng bảng bằng chứng và contract, không mở thêm địa bàn.

## 12. Nguồn, file và cách mở

- [S1] NXB Tài nguyên - Môi trường và Bản đồ Việt Nam: [bản đồ hành chính](https://sapnhap.bando.com.vn). Query và hash raw geometry ở `aoi-manifest.json`; nguồn này xác nhận phạm vi xã, không xác nhận đất/cây.
- [S2] ISRIC: [SoilGrids FAQ và đơn vị](https://docs.isric.org/globaldata/soilgrids/SoilGrids_faqs_01.html), [WCS](https://docs.isric.org/globaldata/soilgrids/wcs.html). Raw coverage, geotags và SHA được lưu; sample riêng tại tâm block ở `study-block-soil-model.json`.
- [S3] METER: [hướng dẫn hiệu chuẩn độ ẩm đất](https://publications.metergroup.com/Sales%20and%20Support/METER%20Environment/Website%20Articles/how-calibrate-soil-moisture-sensors.pdf). Nguyên lý tham khảo, không là đặc tính của probe chưa biết của team.
- [S4] Nguyễn Minh Phượng và cộng sự, CTU 2009, 11:194-199: [PDF](https://ctujsvn.ctu.edu.vn/index.php/ctujsvn/article/download/605/3214/3214). Nghiên cứu lịch sử; không tọa độ xác nhận ruộng Mỹ Thành.
- [S5] Nguyễn Minh Đông, Châu Minh Khôi, Võ Thị Gương, CTU 2009, 11a:262-269: [PDF](https://ctujsvn.ctu.edu.vn/index.php/ctujsvn/article/download/597/3222/3222). Bảng mùa vụ vùng; chưa chứng minh cùng thửa với S4.
- [S6] NASA: [POWER Daily API](https://power.larc.nasa.gov/docs/services/api/temporal/daily/). Chuỗi điểm có QA và cờ chất lượng; không là quan trắc ruộng.
- [S7] NOAA CPC: [bản ENSO tháng 10/2026](https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso_disc_oct2026/ensodisc.shtml). Chỉ dùng outlook có ngày, kiểm bản mới trước pitching.
- [S8] Nguyễn Tân Xuân Tùng, IUH: [luận án 2025](https://ipe.iuh.edu.vn/uploads/2026/03/1.-LUAN-AN-TIEN-SI_NGUYEN-TAN-XUAN-TUNG.pdf), PDF trang 64-65 / trang in 47-48 cho phương pháp thí nghiệm lúa. Có record SHA của bản đã đọc.

**File mở trực tiếp:** `study-block.kml` trong Google Earth; `study-block.geojson` trong QGIS hoặc geojson.io; `study-block-coordinates.csv` trong Excel. `aoi.*` là xã, `study-block.*` là khối minh họa, `illustrative-*` là hình thoi cũ đã hạ trạng thái. Trong ZIP có bảng review 12 hàng `rotation-evidence-review.csv`, hồ sơ vai trò, bản đồ và file nguồn hình học; không gọi đó là dữ liệu địa chính hoặc raw field measurements.

**Lưu ý trước thi:** GO Team cho phép nghiên cứu trước giờ G; project work đợi giờ bắt đầu. Đây là hồ sơ nghiên cứu, không chứng minh sản phẩm đã chạy hoặc miễn quy định dùng artifact có sẵn.

**Tái lập:** native Windows, Python 3.12.14/Pillow 13.0.0, ReportLab và pypdf bundled. Chạy `build_my_thanh_study_block.py` để dựng ranh và sample mô hình từ cache, sau đó `build_bich_site_dossier.py` để xuất PDF. Metadata PDF chứa SHA của Markdown; manifest build ghi hash các input. Render bằng Poppler và kiểm hình trước bàn giao. Không tải lại API nếu snapshot không đổi. Chưa commit/push hoặc gửi tin cho người khác.